#### $ cd ~/catkin_NETID

#### $ catkin_make

#### $ source devel/setup.bash  
#### $ roslaunch ur3_driver vision_driver.launch  

### Part 1 Blob Search
#### $ source devel/setup.bash  
#### $ rosrun lab3pkg_py lab3_image_exec.py  


### Part 2 Coordinate Transformation
#### $ source devel/setup.bash  
#### $ rosrun lab3pkg_py lab3_image_tf_exec.py  


### Part 3 Particle Filters
#### $ source devel/setup.bash  
#### $ roslaunch lab3pkg_py lab3_exec.launch  

