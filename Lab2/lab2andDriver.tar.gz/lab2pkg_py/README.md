#### Terminal 1
$ catkin_make  
$ source devel/setup.bash  
$ roslaunch ur3_driver ur3_driver.launch  

#### Terminal 2
$ source devel/setup.bash  
$ rosrun lab2pkg_py lab2_exec.py  

